book = {"chap1":10 , "chap2":20,"chap3":30}

print(book)

# display single value
print(book["chap1"]) #10

print(book["chap3"]) #30

if "chap6" in book:
    print(book["chap6"])
    
    
# add new key-value to dictionary
book["chap4"] = 40
book["chap5"] = 50

print(book)

# display keys
print(book.keys())

# display values
print(book.values())

# display items
print(book.items())

# remove key-value
book.pop("chap2") # chap2-20 will be removed
print("After pop :",book)

# remove last inserted key - value
book.popitem()
print("After popitem :",book)


#print(book["chap10"])
print(book.get("chap6")) # If not existing .. it returns None


# combining two dictionaries
newbook = {"chap11":110,"chap12":120}

finalbook = {**book,**newbook}
print(finalbook)

# method2
book.update(newbook)  # book is getting updated/modifying
print(book)









