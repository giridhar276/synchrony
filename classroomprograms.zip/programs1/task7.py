# -*- coding: utf-8 -*-
"""
write a program to display the below IP addresses


output:
192.168.0.1
192.168.0.2
192.168.0.3
..
..
192.168.0.10
192.168.1.1
192.168.1.2
192.168.1.3
..
..
192.168.1.10
"""

ip = "192.168.{}.{}"
for val in range(0,2):
    for ival in range(1,11):
        ipaddress = ip.format(val,ival)
        print(ipaddress)