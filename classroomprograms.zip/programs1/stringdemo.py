name = "python programming"
print(name)
print("I love",name)
#                                                      -4  -3 -2 -1  
#p   y   t   h   o   n     p   r   o   g   r   a   m   m    i  n  g
#0   1   2   3   4   5  6  7   8  9   10  11  12  13 14   15  16  17

# string slicing
# string[start:stop:step] # step is optional
print(name[0])
print(name[3])
print(name[0:9])
print(name[0:9:1])
print(name[10:14])
print(name[2:9])
print(name[0:17:2]) # p t o  
print(name[1:17:2])
print(name[1:20:5])
print(name[2:13:3])  # tn
print(name[::])  # name[0:17:1]
print(name[:])   # name[0:17]
print(name[-1])
print(name[-3:-1])  # name[-3:-1:1]

print(name[::-1])




# methods
name = "python programming"
print(name.capitalize())
print(name.title())

print(name.center(40))                              
print(name.center(40,"*"))

print(name.endswith("g"))
print(name.endswith("g",1,10))

print(name.upper())
print(name) # original string will remain same as it is.

print(name.lower())

print(name.replace("python", "java"))
print(name.count("p"))
print(name.count("P"))
print(name.count("P".lower()))
print(name.startswith("p"))
print(name.startswith(("z")))

print(name.isupper())
print(name.islower())
print(name.isalpha())
print(name.isalnum())

aname = "  python "
print(len(aname))
print(len(aname.strip())) # will remove whitepaces at both ends
print(len(aname.lstrip()))
print(len(aname.rstrip()))

# converting string to list
bname = "python:java:unix:tableau"
output= bname.split(":")
print(output)

string = "I love {} and {}" #template - can be reused again n again
print(string.format("unix","java"))
print(string.format("ram","shiva"))

# check for substring
print(name.find("in")) # if substring is existing it returns the index
                       # if not existing .. it returns -1
                       
# simple if
if 1 < 2 :
    print("true")


# if-else block  
if name.find("in") != -1:
    print("substring exists")
    print("inside if")
else:
    print("substring not found")
    print("inside else")
    
# check for substring
if "in" in name:
    print("substring exists")
else:
    print("not found")
    
    
alist = [10,20,30]
if 20 in alist:
    print("exists")
    


color = input("Enter any color :")
print("You entered :",color)
if color == "red":
    print("red color")
elif color == "green":
    print("green color")
elif color == "black":
    print("black color")
else:
    print("some other color")    
    
    
 
'''  
    
level1
level1
level1
level1
if cond:
    level2
    level2
    level2
level1
level1
level1


'''


data = ["python","unix","java"]

output = ",".join(data)
print(output)














