#write a program to count the frequency of each item in the name.


string = input("Enter any string:")

print("you entered :",string)

for char in set(string):
    print(char, string.count(char),"times")
    
    
    
    
# method2

frequency = {}
for char in string:
    if char in frequency:
        frequency[char] +=1
    else:
        frequency[char] = 1
print(frequency)
        


