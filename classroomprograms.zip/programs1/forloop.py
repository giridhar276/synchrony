# range(start,stop,step)
## display all values from 1 to 10
for val in range(1,11):
    print(val)
################ dsiplay odd numbers  
for val in range(1,11,2):
    print(val)
############## display numbers in descending 
for val in range(10,0,-1):
    print(val)
    
#### reading char by char
name = "python"
for char in name:
    print(char)
############ iterating the list
alist = [10,20,30]
for val in alist:
    print(val)
############### iterating dictionary
book = {"chap1":10,"chap2":20}
for key in book.keys():   # display keys only
    print(key)
    
for value in book.values():
    print(value)         # display values
    
for key,value in book.items():
    print(key,value)
    
    
########## iterating set
aset = {10,10,10,20,30}
for val in aset:
    print(val)
    
    