
#### objects should be of same type

print(4 + 4)


print("python" + "programming")

output = "python" + "  " + "programming"
print(output)


data = [10,20,30] + [40,50,60]
print(data)


data = (30,40,50) + (50,60,70)
print(data)


book = {"chap1":10,"chap2":20}
newbook = {"chap3":30}
finalbook = {**book,**newbook}