alist = [56,34,7,12,9,31,68,23,6,5]


print(alist.count(56))

alist.append(90)  # adding single object
print("After appending :",alist)

alist.extend([48,61,18])  # adding multiple values  # list.extend(list)
print("After expanding :",alist)

alist.insert(0,100)   # list.insert(index,value)
print("After inserting :",alist)

#list.pop(index)
alist.pop(1)   # will remove value at index 1
print("After pop :",alist)

alist.remove(6)  # if existing.. that value will be removed
print("After remove :",alist)

if 600 in alist:
    alist.remove(600)
    print("After remove :",alist)
else:
    print("not found")
    
print("get count :",alist.count(100))


alist.sort()
print("sorting in ascending order:", alist)

alist.reverse()
print("reversing :",alist)

## sum of all the elements in list
print(sum(alist))


alist = [10,10,10,20,30,10]
getcount = alist.count(10) #4
for val in range(0,getcount):
    alist.remove(10)
print(alist)


